﻿using System;

namespace Bronk {
    class $safeitemname$ {
        public $safeitemname$(){ 
            
        }
    }
}
